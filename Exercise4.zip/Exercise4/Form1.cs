﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication
{
    public partial class TimeCalculator : Form
    {
        public TimeCalculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Int64 totalSeconds = Convert.ToInt64(txtSec.Text);
            txtSecond.Text = (totalSeconds % 60).ToString();
            txtMin.Text = ((totalSeconds % 3600) / 60).ToString();
            txtHour.Text = ((totalSeconds % 86400) / 3600).ToString();
            txtDay.Text = ((totalSeconds % (86400 * 30)) / 86400).ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDay.Text = "";
            txtHour.Text = "";
            txtMin.Text = "";
            txtSec.Text = "";
            txtSecond.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}